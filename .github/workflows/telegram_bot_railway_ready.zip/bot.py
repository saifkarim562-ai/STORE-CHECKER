import os
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
import shopify_checker

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Get token from environment
TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send welcome message."""
    welcome_text = (
        "👋 *Welcome to Shopify Monitor Bot!*\n\n"
        "I can help you check Shopify stores and products.\n\n"
        "*Available commands:*\n"
        "• /checkstore `<url>` — Check if a store is live\n"
        "• /checkproduct `<store>` `<handle>` — Check a product\n"
        "• /recent `<store>` — Get recent products\n"
        "• /help — Show this help message"
    )
    await update.message.reply_text(welcome_text, parse_mode='Markdown')

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send help message."""
    help_text = (
        "📋 *Shopify Monitor Bot Help*\n\n"
        "*Commands:*\n"
        "• `/checkstore kyliecosmetics.com` — Check store status\n"
        "• `/checkproduct kyliecosmetics.com products/lip-kit` — Check product\n"
        "• `/recent kyliecosmetics.com` — List recent products\n"
        "• `/start` — Welcome message\n"
        "• `/help` — This message\n\n"
        "*Tips:*\n"
        "• You can use domain or full URL\n"
        "• Product handle is the part after `/products/`"
    )
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def check_store(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check a Shopify store status."""
    if not context.args:
        await update.message.reply_text(
            "❌ Please provide a store URL.\nExample: `/checkstore kyliecosmetics.com`",
            parse_mode='Markdown'
        )
        return

    store_url = context.args[0]
    status_msg = await update.message.reply_text("🔍 Checking store...")

    try:
        result = shopify_checker.check_store(store_url)
        await status_msg.edit_text(result, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Error checking store: {e}")
        await status_msg.edit_text(f"❌ Error checking store: {str(e)}")

async def check_product(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check a specific product."""
    if len(context.args) < 2:
        await update.message.reply_text(
            "❌ Please provide store URL and product handle.\n"
            "Example: `/checkproduct kyliecosmetics.com products/lip-kit`",
            parse_mode='Markdown'
        )
        return

    store_url = context.args[0]
    product_handle = context.args[1]
    status_msg = await update.message.reply_text("🔍 Checking product...")

    try:
        result = shopify_checker.check_product(store_url, product_handle)
        await status_msg.edit_text(result, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Error checking product: {e}")
        await status_msg.edit_text(f"❌ Error checking product: {str(e)}")

async def recent_products(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Get recent products from a store."""
    if not context.args:
        await update.message.reply_text(
            "❌ Please provide a store URL.\nExample: `/recent kyliecosmetics.com`",
            parse_mode='Markdown'
        )
        return

    store_url = context.args[0]
    status_msg = await update.message.reply_text("🔍 Fetching recent products...")

    try:
        result = shopify_checker.get_recent_products(store_url)
        await status_msg.edit_text(result, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Error fetching products: {e}")
        await status_msg.edit_text(f"❌ Error: {str(e)}")

def main():
    if not TOKEN:
        logger.error("No TELEGRAM_BOT_TOKEN found! Set it in your .env file.")
        return

    application = Application.builder().token(TOKEN).build()

    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("checkstore", check_store))
    application.add_handler(CommandHandler("checkproduct", check_product))
    application.add_handler(CommandHandler("recent", recent_products))

    logger.info("Bot started! Press Ctrl+C to stop.")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
