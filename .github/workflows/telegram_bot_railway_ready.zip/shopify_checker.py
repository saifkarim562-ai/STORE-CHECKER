import requests
import json

def normalize_domain(url):
    """Normalize store URL to domain format."""
    domain = url.strip().lower()
    domain = domain.replace('https://', '').replace('http://', '')
    domain = domain.split('/')[0]
    if not domain.endswith('.myshopify.com') and '.' not in domain:
        domain += '.myshopify.com'
    return domain

def check_store(url):
    """Check if a Shopify store is live and get basic info."""
    domain = normalize_domain(url)

    # Try store front
    try:
        response = requests.get(f"https://{domain}", timeout=10, allow_redirects=True)
        is_live = response.status_code == 200
    except Exception:
        is_live = False

    # Try Shopify API for store info
    try:
        api_response = requests.get(
            f"https://{domain}/products.json?limit=1",
            timeout=10,
            headers={'User-Agent': 'Mozilla/5.0'}
        )
        has_products = api_response.status_code == 200
        products_data = api_response.json() if has_products else {}
        product_count = len(products_data.get('products', []))
    except Exception:
        has_products = False
        product_count = 0

    # Build result
    status_emoji = "✅" if is_live else "❌"
    platform = "Shopify" if has_products else "Unknown"

    result = f"{status_emoji} *Store Check: {domain}*\n\n"
    result += f"*Status:* {'Live' if is_live else 'Offline/Unavailable'}\n"
    result += f"*Platform:* {platform}\n"

    if has_products:
        result += f"*Products Available:* Yes\n"
        if product_count > 0:
            product = products_data['products'][0]
            result += f"*Sample Product:* {product.get('title', 'N/A')}\n"
    else:
        result += f"*Products API:* Not accessible\n"

    result += "\n💡 *Tip:* Use /checkproduct to inspect a specific item."
    return result

def check_product(url, handle):
    """Check a specific product by handle."""
    domain = normalize_domain(url)
    handle = handle.strip().replace('products/', '')

    try:
        response = requests.get(
            f"https://{domain}/products/{handle}.json",
            timeout=10,
            headers={'User-Agent': 'Mozilla/5.0'}
        )

        if response.status_code != 200:
            return f"❌ Product not found or store API unavailable."

        data = response.json()
        product = data.get('product', {})

        title = product.get('title', 'Unknown')
        product_type = product.get('product_type', 'N/A')
        vendor = product.get('vendor', 'N/A')
        tags = ', '.join(product.get('tags', [])[:5]) or 'None'

        # Get variants info
        variants = product.get('variants', [])
        variant_info = ""
        if variants:
            for v in variants[:3]:  # Show first 3 variants
                price = v.get('price', 'N/A')
                sku = v.get('sku', 'N/A')
                available = v.get('available', False)
                stock = "✅ In Stock" if available else "❌ Out of Stock"
                variant_info += f"  • {v.get('title', 'Default')}: ${price} — {stock}\n"

        result = (
            f"📦 *{title}*\n\n"
            f"*Vendor:* {vendor}\n"
            f"*Type:* {product_type}\n"
            f"*Tags:* {tags}\n\n"
            f"*Variants:*\n{variant_info}"
        )
        return result

    except Exception as e:
        return f"❌ Error checking product: {str(e)}"

def get_recent_products(url, limit=5):
    """Get recent products from a store."""
    domain = normalize_domain(url)

    try:
        response = requests.get(
            f"https://{domain}/products.json?limit={limit}",
            timeout=10,
            headers={'User-Agent': 'Mozilla/5.0'}
        )

        if response.status_code != 200:
            return f"❌ Could not fetch products from {domain}"

        data = response.json()
        products = data.get('products', [])

        if not products:
            return f"📭 No products found on {domain}"

        result = f"🛍️ *Recent Products from {domain}*\n\n"
        for i, p in enumerate(products, 1):
            title = p.get('title', 'Unknown')
            ptype = p.get('product_type', '')
            handle = p.get('handle', '')
            price = p.get('variants', [{}])[0].get('price', 'N/A')

            result += f"{i}. *{title}*\n"
            if ptype:
                result += f"   Type: {ptype}\n"
            result += f"   Price: ${price}\n"
            result += f"   Handle: `{handle}`\n\n"

        return result

    except Exception as e:
        return f"❌ Error: {str(e)}"
