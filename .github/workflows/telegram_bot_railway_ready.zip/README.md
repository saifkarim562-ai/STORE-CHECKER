# Shopify Monitor Telegram Bot

A Telegram bot to check Shopify store status, products, and availability.

## Features

- ✅ Check if a Shopify store is live
- 📦 Check specific product details (price, stock, variants)
- 🛍️ List recent products from a store
- 🔍 Works with any public Shopify store

## Setup

1. **Get a Telegram Bot Token**
   - Message [@BotFather](https://t.me/BotFather) on Telegram
   - Create a new bot and copy the token

2. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure**
   ```bash
   cp .env.example .env
   # Edit .env and add your TELEGRAM_BOT_TOKEN
   ```

4. **Run**
   ```bash
   python bot.py
   ```

## Commands

| Command | Description | Example |
|---------|-------------|---------|
| `/start` | Welcome message | `/start` |
| `/help` | Show help | `/help` |
| `/checkstore` | Check store status | `/checkstore kyliecosmetics.com` |
| `/checkproduct` | Check product | `/checkproduct kyliecosmetics.com products/lip-kit` |
| `/recent` | List recent products | `/recent kyliecosmetics.com` |

## Notes

- The bot uses Shopify's public `.json` endpoints
- Some stores may block API access or require authentication
- Only works with publicly accessible stores

## License

MIT
